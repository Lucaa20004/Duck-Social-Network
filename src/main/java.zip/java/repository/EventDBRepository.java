package repository;

import domain.Event;
import domain.RaceEvent; // Clasa specifică pe care o salvăm
import domain.User;
import repository.*;
import validation.Validator;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

// Clasa necesară pentru a citi obiectele Culoar (pentru RaceEvent)
import domain.Culoar;

public class EventDBRepository implements Repository<Long, Event> {
    private final String url;
    private final String username;
    private final String password;
    private final Validator<Event> validator;
    private final Repository<Long, User> userRepo;

    public EventDBRepository(String url, String username, String password,
                             Validator<Event> validator, Repository<Long, User> userRepo) {
        this.url = url;
        this.username = username;
        this.password = password;
        this.validator = validator;
        this.userRepo = userRepo;
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    }

    // --- METODE AJUTĂTOARE (RELATII M-to-M) ---

    // Încarcă abonații și îi pune pe obiectul Event
    private void loadSubscribers(Event event) {
        List<User> subscribers = new ArrayList<>();
        String sql = "SELECT user_id FROM event_subscribers WHERE event_id = ?";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setLong(1, event.getId());
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    Long userId = rs.getLong("user_id");

                    // --- FIX: Aici era eroarea! Apelăm findOne() și primim direct User ---
                    User user = userRepo.findOne(userId); // <-- Folosim tipul User

                    // Dacă user-ul a fost găsit, îl adăugăm
                    if (user != null) { // <-- Verificăm doar dacă nu este null
                        subscribers.add(user);
                    }
                }
            }
            event.getSubscribers().addAll(subscribers);

        } catch (SQLException e) {
            System.err.println("Eroare la încărcarea subscriberilor: " + e.getMessage());
        }
    }
    // Salvează abonații în tabela de legătură
    private void saveSubscribers(Event entity) {
        String sql = "INSERT INTO event_subscribers (event_id, user_id) VALUES (?, ?)";
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            for (User user : entity.getSubscribers()) {
                statement.setLong(1, entity.getId());
                statement.setLong(2, user.getId());
                statement.addBatch();
            }
            statement.executeBatch();

        } catch (SQLException e) {
            System.err.println("Eroare la salvarea subscriberilor: " + e.getMessage());
        }
    }

    // Extrage Event-ul (şi RaceEvent-ul) din ResultSet
    private Event extractEvent(ResultSet rs) throws SQLException {
        Long id = rs.getLong("id");
        String nume = rs.getString("nume_eveniment");
        String type = rs.getString("event_type");

        // --- LOGICĂ SPECIFICĂ RACEEVENT ---
        if ("RACEEVENT".equals(type)) {
            // NOTĂ: Dacă ai stoca distanțele culoarului ca un șir JSON sau text în DB,
            // ar trebui să le citești și să le reconstruiești aici.

            // Pentru simplificare, vom crea RaceEvent cu o listă goală de Culoar.
            // (Presupunem că nu ai coloane suplimentare pentru RaceEvent)
            List<Culoar> emptyCuloare = new ArrayList<>();
            RaceEvent raceEvent = new RaceEvent(id, nume, emptyCuloare);

            loadSubscribers(raceEvent); // Incarcăm relațiile
            return raceEvent;
        }

        // Event generic (fallback)
        Event event = new Event(id, nume);
        loadSubscribers(event); // Incarcăm relațiile
        return event;
    }


    // --- IMPLEMENTAREA METODELOR REPOSITORY ---

    @Override
    public Event findOne(Long id) { // <-- FIX 1: Schimbat din Optional<Event> în Event
        if (id == null) {
            throw new IllegalArgumentException("ID-ul nu poate fi null!");
        }
        String sql = "SELECT id, nume_eveniment, event_type FROM events WHERE id = ?";
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setLong(1, id);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return extractEvent(rs); // Returnează direct Event
                }
            }
        } catch (SQLException e) {
            System.err.println("Eroare findOne: " + e.getMessage());
        }
        return null; // Returnează null conform interfeței tale
    }

    @Override
    public Iterable<Event> findAll() {
        List<Event> events = new ArrayList<>();
        String sql = "SELECT id, nume_eveniment, event_type FROM events";
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                events.add(extractEvent(rs));
            }

        } catch (SQLException e) {
            System.err.println("Eroare findAll: " + e.getMessage());
        }
        return events;
    }

    @Override
    public Event save(Event entity) {
        if (entity == null) {
            throw new IllegalArgumentException("Entitatea nu poate fi null!");
        }
        validator.validate(entity);

        // 1. Inserare în tabela events
        String sql = "INSERT INTO events (event_type, nume_eveniment) VALUES (?, ?)";
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            // Discriminator: Dacă e RaceEvent, setăm RACEEVENT
            if (entity instanceof RaceEvent) {
                statement.setString(1, "RACEEVENT");
            } else {
                statement.setString(1, "EVENT");
            }

            statement.setString(2, entity.getNume());

            statement.executeUpdate();

            // Preluăm ID-ul generat de baza de date
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    Long newId = generatedKeys.getLong(1);
                    entity.setId(newId);
                } else {
                    return entity;
                }
            }

        } catch (SQLException e) {
            System.err.println("Eroare save (Event): " + e.getMessage());
            return entity;
        }

        // 2. Salvarea subscriberilor în tabela de legătură
        if (entity.getSubscribers() != null && !entity.getSubscribers().isEmpty()) {
            saveSubscribers(entity);
        }

        return null; // Salvare reușită
    }

    @Override
    public Event delete(Long id) {
        if (id == null) {
            throw new IllegalArgumentException("ID-ul nu poate fi null!");
        }

        // Ștergerea se bazează pe ON DELETE CASCADE din schema SQL
        String sql = "DELETE FROM events WHERE id = ?";
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setLong(1, id);
            statement.executeUpdate();

        } catch (SQLException e) {
            System.err.println("Eroare delete: " + e.getMessage());
        }
        return null;
    }

    @Override
    public Event update(Event entity) {
        // Implementare: No-op pentru simplitate
        return null;
    }
}