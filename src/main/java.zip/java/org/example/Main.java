package org.example;

import domain.*;
import exeption.UserNotFoundExeption;
import exeption.ValidationExeption;
import repository.NetworkManager;
import repository.*;
import ui.ConsoleUI;
import validation.*;
import service.DuckService;
import java.time.LocalDate;
import java.util.*;

public class Main {

    public static void main(String[] args) {

        String dbUrl = "jdbc:postgresql://localhost:5432/Duck"; // Pune numele bazei tale aici
        String dbUser = "postgres";
        String dbPass = "kapy2019";


        NetworkManager networkManager = new NetworkManager();

        Validator<User> userValidator = new UserValidator();
        Validator<Card> cardValidator = new CardValidator();
        Validator<Event> eventValidator = new EventValidator();

        Repository<Long, User> userRepo1 = new UserDBRepository(
                dbUrl, dbUser, dbPass, new UserValidator()
        );
        Repository<Long, Card> cardRepo1 = new CardDBRepository(dbUrl, dbUser, dbPass, new CardValidator());

        FriendshipDBRepository friendRepo1 = new FriendshipDBRepository(dbUrl, dbUser, dbPass);
        EventDBRepository eventRepo1 = new EventDBRepository(dbUrl, dbUser, dbPass, eventValidator, userRepo1);
        UserRepository userRepo = new UserRepository(userValidator);
        FriendshipRepository friendRepo = new FriendshipRepository();
        CardRepository cardRepo = new CardRepository(cardValidator);
        EventRepository eventRepo = new EventRepository(eventValidator);
        DuckService network = new DuckService(userRepo1,friendRepo1,cardRepo1,eventRepo1);
        //loadInitialData(network);


        ConsoleUI ui = new ConsoleUI(network);

        ui.run();
    }


    private static void loadInitialData(DuckService network) {
        System.out.println("Se încarcă datele...");

        try {

            try {
                network.addFriendship(1L, 2L); // John - Alice
                network.addFriendship(2L, 3L); // Alice - Bob
                network.addFriendship(4L, 5L); // Daffy - Donald
                System.out.println("    - Prietenii încărcate.");
            } catch (Exception e) {
                System.err.println("    ! Avertisment prietenii: " + e.getMessage());
            }

            List<Culoar> list = new ArrayList<>();
            list.add(new Culoar(3));
            list.add(new Culoar(6));
            list.add(new Culoar(10));

            RaceEvent defaultRace = new RaceEvent(null, "Cursa Default", list);
            network.saveEvent(defaultRace);

            System.out.println("    - Cursa default creată.");

        } catch (Exception e) {
            System.err.println("Eroare critică la încărcarea datelor: " + e.getMessage());
        }
    }
}
