package domain;

import domain.tiprata.Inotator; // Interfața Inotator
import service.race.*; // Importă pachetul cu logica Natație
import domain.*;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

public class RaceEvent extends Event{
    private final List<Culoar> culoare;
    private final List<Duck> participants;

    public RaceEvent(Long id, String nume, List<Culoar> culoare) {
        super(id, nume);
        this.culoare = culoare;
        this.participants = new  ArrayList<>();
    }

    public void addParticipant(Duck duck) throws Exception {
        if (duck instanceof Inotator) {
            if (!participants.contains(duck)) {
                participants.add(duck);
            }
        } else {
            throw new Exception(duck.getUsername() + " nu poate participa la o cursă de înot!");
        }
    }

    private void findAllParticipants(Map<Long, User> allUsers) {
        this.participants.clear();

        for (User user : allUsers.values()) {
            if (user instanceof Inotator) {
                this.participants.add((Duck) user);
            }
        }
    }

    public void runRace(Map<Long, User> allUsers) {

        findAllParticipants(allUsers);
        System.out.println("Am gasit " + participants.size() + " inotatori eligibili in retea.");

        Culoar[] culoareArray = this.culoare.toArray(new Culoar[0]);

                Duck[] raceDucks = new Duck[participants.size()];
        for (int i = 0; i < participants.size(); i++) {
            Duck d = participants.get(i);
            raceDucks[i] = d;
        }

        if (raceDucks.length < culoareArray.length) {
            notifySubscribers("Cursa a fost anulata. Nu sunt suficienți inotatori ("
                    + raceDucks.length + ") pentru " + culoareArray.length + " culoare.");
            return;
        }

        StrategyFactory factory = new DuckStrategyFactory();
        Strategy strategy = factory.createStrategy(Strategy_type.BINARY_S);
        Result result = strategy.solve(raceDucks, culoareArray);

        Duck[] ducks = result.getDucks();
        Culoar[] culoare = result.getCuloare();
        for (int i = 0; i < ducks.length; i++) {
            double timpCuloar = 2 * culoare[i].getDistanta() / ducks[i].getViteza();

            System.out.printf("Duck %d on lane %d: t=%.2f secunde%n",
                    i + 1,
                    i + 1,
                    timpCuloar
            );

        }

        //notifySubscribers(rezultatCursa);
    }



}
