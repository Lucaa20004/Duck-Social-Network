package domain;

public enum TipRata {
    FLYING,
    SWIMMING,
    FLYING_AND_SWIMMING
}
