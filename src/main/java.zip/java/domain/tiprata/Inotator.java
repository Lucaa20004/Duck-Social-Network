package domain.tiprata;

public interface Inotator {
    void inoata();
}
