package domain.tiprata;

public interface Zburator {
    void zboara();
}
