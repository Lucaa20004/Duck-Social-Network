package domain;

public class Culoar {
    private double distanta;

    public Culoar(double distanta) {
        this.distanta = distanta;
    }

    public double getDistanta() {
        return distanta;
    }

    public void setDistanta(double distanta) {
        this.distanta = distanta;
    }
}
