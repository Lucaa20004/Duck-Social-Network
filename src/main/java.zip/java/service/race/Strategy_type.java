package service.race;

public enum Strategy_type {
    BINARY_S,
    BRUTE_S
}

