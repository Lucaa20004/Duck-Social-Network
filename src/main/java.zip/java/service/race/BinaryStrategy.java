package service.race;

import java.util.*;
import domain.*;

public class BinaryStrategy implements Strategy {

    @Override
    public Result solve(Duck[] ducks, Culoar[] culoare) {
        int N = ducks.length;
        int M = culoare.length;

        // Sortăm culoarele crescător după distanță (COREECT)
        Arrays.sort(culoare, Comparator.comparingDouble(Culoar::getDistanta));

        // --- FIX 1: Sortăm rațele DESCĂTOR (DESC) ---
        // Prioritizăm rațele mai rezistente, apoi pe cele mai rapide.
        Arrays.sort(ducks, (d1, d2) -> {
            // Rezistență DESC (d2 vs d1)
            int cmpRez = Double.compare(d2.getRezistenta(), d1.getRezistenta());
            if (cmpRez != 0) return cmpRez;
            // Viteză DESC (d2 vs d1)
            return Double.compare(d2.getViteza(), d1.getViteza());
        });

        double left = 0.0, right = 1e12;
        double eps = 1e-4;

        // Căutăm timpul minim posibil
        while (right - left > eps) {
            double mid = (left + right) / 2;
            if (canFinish(ducks, culoare, mid))
                right = mid;
            else
                left = mid;
        }

        // Reconstrucție rezultat final pentru timpul minim
        AssignmentResult assignment = assignDucks(ducks, culoare, right);
        return new Result(right, assignment.ducks, assignment.culoare);
    }

    /**
     * Verifică dacă putem aloca M rațe pentru timp ≤ T.
     */
    private boolean canFinish(Duck[] ducks, Culoar[] culoare, double T) {
        boolean[] used = new boolean[ducks.length];
        int M = culoare.length;

        // Inițializarea la o valoare care permite primei rațe să fie aleasă
        double lastRezistenta = Double.POSITIVE_INFINITY;

        for (int i = 0; i < M; i++) {
            int bestDuckIndex = -1; // Câștigătorul alocării curente
            double maxSpeed = -1; // Căutăm viteza maximă
            double dist = culoare[i].getDistanta();

            for (int j = 0; j < ducks.length; j++) {
                if (used[j]) continue;

                // 1. CONSTRÂNGEREA DE REZISTENȚĂ CORECTĂ (r_j <= r_last)
                // Dacă rața curentă e mai rezistentă decât ultima alocată, O IGNORĂM
                if (ducks[j].getRezistenta() > lastRezistenta) {
                    continue;
                }

                // 2. CONSTRÂNGEREA DE TIMP
                double t = 2 * dist / ducks[j].getViteza();

                if (t <= T) {
                    // 3. SELECȚIA LACMĂ: Găsim cea mai rapidă rață (nu doar prima găsită)
                    if (ducks[j].getViteza() > maxSpeed) {
                        maxSpeed = ducks[j].getViteza();
                        bestDuckIndex = j; // Stocăm indexul celui mai bun candidat
                    }
                }
            }

            // DUPĂ bucla interioară, alocăm cel mai bun candidat:
            if (bestDuckIndex != -1) {
                used[bestDuckIndex] = true;
                lastRezistenta = ducks[bestDuckIndex].getRezistenta();
            } else {
                return false; // Alocarea a eșuat
            }
        }
        return true; // Toate culoarele au primit rață
    }

    private static class AssignmentResult {
        Duck[] ducks;
        Culoar[] culoare;

        AssignmentResult(Duck[] ducks, Culoar[] culoare) {
            this.ducks = ducks;
            this.culoare = culoare;
        }
    }

    /**
     * Reconstruiește alocarea finală.
     */
    // IN BinaryStrategy.java (metoda assignDucks)

    private AssignmentResult assignDucks(Duck[] ducks, Culoar[] culoare, double T) {
        boolean[] used = new boolean[ducks.length];
        List<Duck> rezultatDucks = new ArrayList<>();
        List<Culoar> rezultatCuloare = new ArrayList<>();
        double lastRezistenta = Double.POSITIVE_INFINITY; // Inițializare corectă

        for (int i = 0; i < culoare.length; i++) {
            int bestDuckIndex = -1;
            double maxSpeed = -1;
            double dist = culoare[i].getDistanta();

            for (int j = 0; j < ducks.length; j++) {
                if (used[j]) continue;

                // 1. Constrângerea (r_j <= r_last)
                if (ducks[j].getRezistenta() > lastRezistenta) continue;

                // 2. Constrângerea de timp
                double t = 2 * dist / ducks[j].getViteza();

                if (t <= T) {
                    // 3. Selecția lacomă
                    if (ducks[j].getViteza() > maxSpeed) {
                        maxSpeed = ducks[j].getViteza();
                        bestDuckIndex = j;
                    }
                }
            }

            // Alocarea
            if (bestDuckIndex != -1) {
                used[bestDuckIndex] = true;
                lastRezistenta = ducks[bestDuckIndex].getRezistenta();
                rezultatDucks.add(ducks[bestDuckIndex]);
                rezultatCuloare.add(culoare[i]);
            } else {
                // Dacă nu a găsit o alocare validă pentru timpul T,
                // returnează rezultatul incomplet
                break;
            }
        }

        return new AssignmentResult(
                rezultatDucks.toArray(new Duck[0]),
                rezultatCuloare.toArray(new Culoar[0])
        );
    }
}
