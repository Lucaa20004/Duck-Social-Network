package service;

import domain.*;
import repository.*;
import repository.CardDBRepository;
import repository.EventDBRepository;
import repository.FriendshipDBRepository;
import repository.UserDBRepository;
import repository.InMemoryRepository; // Păstrăm importul pentru getEntitiesMap
import exeption.UserNotFoundExeption;
import exeption.ValidationExeption;

import java.util.*;

public class DuckService {

    // Dependențele injectate
    private final Repository<Long, User> userRepo;
    private final FriendshipDBRepository friendRepo;
    private final Repository<Long, Card> cardRepo;
    private final Repository<Long, Event> eventRepo;


    public DuckService(Repository<Long, User> userRepo,
                       FriendshipDBRepository friendRepo,
                       Repository<Long, Card> cardRepo,
                       Repository<Long, Event> eventRepo) {
        this.userRepo = userRepo;
        this.friendRepo = friendRepo;
        this.cardRepo = cardRepo;
        this.eventRepo = eventRepo;
    }

    // --- User Operations (Core CRUD) ---

    public void addUser(User user) throws ValidationExeption {
        User saved = userRepo.save(user);
        if (saved != null) {
            throw new ValidationExeption("Utilizatorul cu acest ID există deja sau eroare la salvare!");
        }
        // Inițializăm nodul în graful de prietenii (folosit de algoritm)
        friendRepo.save(user.getId());
    }

    public void removeUser(Long userId) throws UserNotFoundExeption {
        if (userRepo.findOne(userId) == null) {
            throw new UserNotFoundExeption("Utilizatorul nu există!");
        }
        userRepo.delete(userId);
        friendRepo.delete(userId); // Șterge legăturile din DB/memorie
        System.out.println("Utilizator șters.");
    }

    // --- Friendship Operations ---

    public void addFriendship(Long userId1, Long userId2) throws UserNotFoundExeption {
        if (userRepo.findOne(userId1) == null || userRepo.findOne(userId2) == null) {
            throw new UserNotFoundExeption("Utilizatorii trebuie să existe!");
        }
        friendRepo.addFriendship(userId1, userId2); // Face INSERT în DB
        System.out.println("Prietenie adăugată.");
    }

    public void removeFriendship(Long userId1, Long userId2) throws UserNotFoundExeption {
        if (userRepo.findOne(userId1) == null || userRepo.findOne(userId2) == null) {
            throw new UserNotFoundExeption("Utilizatorii trebuie să existe!");
        }
        friendRepo.removeFriendship(userId1, userId2); // Face DELETE în DB
        System.out.println("Prietenie ștearsă.");
    }

    // --- Card Operations ---

    public void addCard(Card card) {
        cardRepo.save(card);
        System.out.println("Card adăugat: " + card.getNumeCard());
    }

    /**
     * Adaugă o rață unui cârd (Logica Many-to-Many).
     */
    public void addToCard(Long cardId, Long userId) throws Exception {
        User user = userRepo.findOne(userId);
        if (user == null || !(user instanceof Duck)) {
            throw new UserNotFoundExeption("ID-ul nu aparține unei rațe.");
        }
        Card card = cardRepo.findOne(cardId);
        if (card == null) {
            throw new Exception("Cardul nu există.");
        }

        Duck duckToAdd = (Duck) user;

        // 1. Actualizează în memoria obiectului Card (pentru afișare imediată)
        card.addMembru(duckToAdd);

        // 2. Persistă relația în Baza de Date (tabela membri_card)
        if (cardRepo instanceof CardDBRepository) {
            ((CardDBRepository) cardRepo).addMemberToCard(cardId, userId);
        }

        System.out.println("Succes! Rața " + duckToAdd.getUsername() + " a fost adăugată în cârd.");
    }

    // --- Display and Linking Logic ---

    public void afiseazaCard() {
        Iterable<Card> cards = cardRepo.findAll();

        // Dacă suntem pe baza de date, trebuie să încărcăm manual membrii
        if (cardRepo instanceof CardDBRepository) {
            // 1. Luăm relațiile din DB
            Map<Long, List<Long>> memberships = ((CardDBRepository) cardRepo).loadAllMemberships();

            // 2. Iterăm prin carduri și le populăm
            for (Card c : cards) {
                List<Long> memberIds = memberships.get(c.getId());

                // Curățăm map-ul intern al cardului (care ar fi gol oricum)
                if (c.getMembri() != null) { c.getMembri().clear(); }

                if (memberIds != null) {
                    for (Long userId : memberIds) {
                        User u = userRepo.findOne(userId); // Fetch Duck object from DB
                        if (u instanceof Duck) {
                            try {
                                c.addMembru((Duck) u); // Repopulăm obiectul în memorie
                            } catch (Exception ignored) { }
                        }
                    }
                }
            }
        }

        // 3. Afișarea efectivă
        int count = 0; for (Card c : cards) count++;
        System.out.println("--- Carduri (" + count + ") ---");
        for (Card card : cards) {
            System.out.println("Card ID: " + card.getId() + ", Nume: " + card.getNumeCard());
            Map<Long, Duck> membri = card.getMembri();
            if (membri.isEmpty()) {
                System.out.println("  Membri: Niciunul");
            } else {
                System.out.println("  Membri (" + membri.size() + "):");
                membri.values().forEach(duck -> {
                    System.out.println("    - " + duck.getUsername() + " (ID: " + duck.getId() + ")");
                });
            }
            System.out.println();
        }
    }

    // --- Event Operations ---

    public void saveEvent(Event event) {
        eventRepo.save(event);
        System.out.println("Eveniment adăugat: " + event.getNume());
    }

    public void runRaceEvent(Long eventId) throws Exception {
        Event event = eventRepo.findOne(eventId);
        if (event == null) {
            throw new Exception("Evenimentul nu a fost găsit.");
        }
        if (!(event instanceof RaceEvent)) {
            throw new Exception("Evenimentul nu este o cursă.");
        }

        String mesajStart = "A inceput cursa: " + event.getNume();
        event.notifySubscribers(mesajStart);

        Map<Long, User> allUsers = getEntitiesMap(userRepo);

        System.out.println("--- Se pornește cursa: " + event.getNume() + " ---");
        ((RaceEvent) event).runRace(allUsers);
        System.out.println("--- Cursa s-a încheiat ---");

        String mesajStop = "Cursa '" + event.getNume() + "' s-a terminat.";
        event.notifySubscribers(mesajStop);
    }

    public void subscribeToEvent(Long userID , Long eventID) throws Exception {
        User user = userRepo.findOne(userID);
        if (user == null) {
            throw new Exception("Nu există utilizatorul cu acest ID");
        }
        Event event = eventRepo.findOne(eventID);
        if (event == null) {
            throw new Exception("Evenimentul nu a fost găsit");
        }

        event.subscribe(user);
        String mesajNotificare = "Ați fost abonat cu succes la evenimentul '" + event.getNume() + "'.";

        if(user.getMesaje() != null) {
            user.getMesaje().add(mesajNotificare);
        }
        System.out.println("Utilizatorul a fost notificat (mesaj adăugat în lista sa).");
    }

    public void unsubscribeRoEvent(Long userID , Long eventID) throws Exception {
        User user = userRepo.findOne(userID);
        if (user == null) {
            throw new Exception("Nu există utilizatorul cu acest ID");
        }
        Event event = eventRepo.findOne(eventID);
        if (event == null) {
            throw new Exception("Evenimentul nu a fost găsit");
        }

        event.unsubscribe(user);
        String mesajNotificare = "Ați fost dezabonat cu succes de la evenimentul '" + event.getNume() + "'.";

        if(user.getMesaje() != null) {
            user.getMesaje().add(mesajNotificare);
        }
        System.out.println("Utilizatorul a fost notificat.");
    }

    public void afiseazaSubscriber(Long eventID) {
        Event event = eventRepo.findOne(eventID);
        if (event == null) {
            System.out.println("Evenimentul nu există.");
            return;
        }

        List<User> subscribers = event.getSubscribers();
        if (subscribers.isEmpty()) {
            System.out.println("Acest eveniment nu are niciun abonat.");
        } else {
            System.out.println("--- Abonați la " + event.getNume() + " ---");
            for (User user : subscribers) {
                System.out.println("- " + user.getUsername() + " (ID: " + user.getId() + ")");
            }
        }
    }

    // --- Utility and Graph Methods ---

    public Map<Long, Set<Long>> getFriendships() {
        return friendRepo.getFriendships();
    }


    public int getCommunityCount() {
        Map<Long, User> users = getEntitiesMap(userRepo);
        Set<Long> visited = new HashSet<>();
        int count = 0;
        for (Long userId : users.keySet()) {
            if (!visited.contains(userId)) {
                count++;
                dfs(userId, visited);
            }
        }
        return count;
    }

    public Set<User> getMostSociableCommunity() {
        Map<Long, User> users = getEntitiesMap(userRepo);
        List<Set<Long>> components = findAllComponents();
        int maxDiameter = -1;
        Set<Long> bestComponentIds = null;

        for (Set<Long> component : components) {
            int diameter = getComponentDiameter(component);
            if (diameter > maxDiameter) {
                maxDiameter = diameter;
                bestComponentIds = component;
            }
        }

        Set<User> mostSociableCommunity = new HashSet<>();
        if (bestComponentIds != null) {
            for (Long id : bestComponentIds) {
                mostSociableCommunity.add(users.get(id));
            }
        }
        System.out.println("Diametrul maxim găsit: " + maxDiameter);
        return mostSociableCommunity;
    }

    // ... (restul helper-ilor de graf: getComponentDiameter, bfsForEccentricity, etc.)


    private int getComponentDiameter(Set<Long> component) {
        int maxDiameter = 0;
        for (Long startNode : component) {
            int eccentricity = bfsForEccentricity(startNode, component);
            maxDiameter = Math.max(maxDiameter, eccentricity);
        }
        return maxDiameter;
    }

    private int bfsForEccentricity(Long startNode, Set<Long> component) {
        Map<Long, Set<Long>> friendships = friendRepo.getFriendships();
        Map<Long, Integer> distance = new HashMap<>();
        Queue<Long> queue = new LinkedList<>();

        distance.put(startNode, 0);
        queue.add(startNode);
        int maxDist = 0;

        while (!queue.isEmpty()) {
            Long current = queue.poll();
            if (friendships.get(current) != null) {
                for (Long neighbor : friendships.get(current)) {
                    if (component.contains(neighbor) && !distance.containsKey(neighbor)) {
                        int newDist = distance.get(current) + 1;
                        distance.put(neighbor, newDist);
                        queue.add(neighbor);
                        maxDist = Math.max(maxDist, newDist);
                    }
                }
            }
        }
        return maxDist;
    }

    private List<Set<Long>> findAllComponents() {
        Map<Long, User> users = getEntitiesMap(userRepo);
        List<Set<Long>> components = new ArrayList<>();
        Set<Long> visited = new HashSet<>();
        for (Long userId : users.keySet()) {
            if (!visited.contains(userId)) {
                Set<Long> currentComponent = new HashSet<>();
                dfsFindComponent(userId, visited, currentComponent);
                components.add(currentComponent);
            }
        }
        return components;
    }

    private void dfsFindComponent(Long userId, Set<Long> visited, Set<Long> currentComponent) {
        Map<Long, Set<Long>> friendships = friendRepo.getFriendships();
        visited.add(userId);
        currentComponent.add(userId);

        if (friendships.get(userId) != null) {
            for (Long friendId : friendships.get(userId)) {
                if (!visited.contains(friendId)) {
                    dfsFindComponent(friendId, visited, currentComponent);
                }
            }
        }
    }

    private void dfs(Long userId, Set<Long> visited) {
        Map<Long, Set<Long>> friendships = friendRepo.getFriendships();
        visited.add(userId);
        if (friendships.get(userId) != null) {
            for (Long friendId : friendships.get(userId)) {
                if (!visited.contains(friendId)) {
                    dfs(friendId, visited);
                }
            }
        }
    }

    public void afiseazaMesaje(Long userID) {
        User user = userRepo.findOne(userID);
        if (user == null) {
            System.err.println("Eroare: Utilizatorul cu ID " + userID + " nu a fost găsit.");
            return;
        }

        List<String> mesaje = user.getMesaje();
        System.out.println("--- Mesaje pentru: " + user.getUsername() + " ---");

        if (mesaje == null || mesaje.isEmpty()) {
            System.out.println("Utilizatorul nu are mesaje noi.");
        } else {
            for (int i = 0; i < mesaje.size(); i++) {
                System.out.println((i + 1) + ". " + mesaje.get(i));
            }
        }
    }

    public void afiseazaRetea() {
        Iterable<User> users = userRepo.findAll();
        Map<Long, Set<Long>> friendships = friendRepo.getFriendships();

        int count = 0;
        for(User u : users) count++;

        System.out.println("--- Utilizatori (" + count + ") ---");
        users.forEach(System.out::println);

        System.out.println("--- Prietenii ---");
        friendships.forEach((userId, friends) -> {
            User u = userRepo.findOne(userId);
            if(u != null) {
                System.out.print(u.getUsername() + " e prieten cu: ");
                if (friends.isEmpty()) {
                    System.out.println("nimeni");
                } else {
                    friends.forEach(friendId -> {
                        User friend = userRepo.findOne(friendId);
                        if(friend != null) System.out.print(friend.getUsername() + " ");
                    });
                    System.out.println();
                }
            }
        });
        System.out.println("-----------------");
    }

    private <ID, E extends Entity<ID>> Map<ID, E> getEntitiesMap(Repository<ID, E> repo) {
        // Această metodă este crucială pentru compatibilitatea cu algoritmii de graf
        // care au nevoie de cheile utilizatorilor.
        if (repo instanceof InMemoryRepository) {
            // Dacă este InMemory, castăm și luăm mapa direct
            return ((InMemoryRepository<ID, E>) repo).getEntities();
        }
        // Altfel (pentru DB), construim mapa din rezultatul Iterable
        Map<ID, E> map = new HashMap<>();
        for (E entity : repo.findAll()) {
            map.put(entity.getId(), entity);
        }
        return map;
    }
}